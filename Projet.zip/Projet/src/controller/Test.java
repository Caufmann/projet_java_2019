package Controller;
import View.*;

public class Test {

        public static void main(String[] s){
            Menu window = new Menu();
            // Udpatebdd upd = new Udpatebdd();
        }
    }
