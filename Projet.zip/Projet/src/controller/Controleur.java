package Controller;
import Controller.Connexion;

public abstract class Controleur <T> {

        protected Connexion connect = null;

        public Controleur(Connexion conn){
            this.connect = conn;
        }

        /**
         * MÃ©thode de crÃ©ation
         * @param obj
         * @return boolean
         */
        public abstract boolean create(T obj);

        /**
         * MÃ©thode pour effacer
         * @param obj
         * @return boolean
         */
        public abstract boolean delete(T obj);

        /**
         * MÃ©thode de mise Ã  jour
         * @param obj
         * @return boolean
         */
        public abstract boolean update(T obj);

        /**
         * MÃ©thode de recherche des informations
         * @param id
         * @return T
         */
        public abstract T find(int id);

        /**
         * MÃ©thode de recherche des informations
         * @param name
         * @return T
         */

        public abstract T find (int id, String name);

        public abstract T find (int id, int id1, int id2);

        public abstract T recherch (int id, String name);
    }

