/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testbouton;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel; 
import java.awt.Color; 
import java.awt.GridLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
/**
 *
 * @author inesguermonprez
 */

public class Fenetre extends JFrame{
    
    private JPanel pan = new JPanel(); 
    private JPanel pan2 = new JPanel(); 
    
    private JLabel label1 = new JLabel(); 
    private JLabel label2 = new JLabel(); 
    private JLabel label3 = new JLabel();
    private JTextField text1 = new JTextField();
    private JLabel label4 = new JLabel();
    private JPasswordField password1 = new JPasswordField(); 
    private JButton connect = new JButton(); 
    
   
    //Constructeur
    public Fenetre(){
        
     
        this.setTitle("Ma fenetre"); 
        this.setSize(1200,800); 
        this.setLocationRelativeTo(null); 
        this.setLayout(new BorderLayout()); 
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
        pan.setLayout(null);
       

        label1.setFont(new java.awt.Font("SERomand", 0, 70)); // NOI18N
        label1.setText("Connexion");
        pan.add(label1);
        label1.setBounds(120, 80, 410, 160);

        label2.setFont(new java.awt.Font("SERomand", 1, 48)); // NOI18N
        label2.setText("Login :");
        pan.add(label2);
        label2.setBounds(270, 330, 170, 80);

        label3.setFont(new java.awt.Font("SERomand", 1, 48)); // NOI18N
        label3.setText("Password:");
        pan.add(label3);
        label3.setBounds(270, 430, 360, 60);
        
        text1.setFont(new java.awt.Font("SERomand", 0, 24)); // NOI18N
        pan.add(text1);
        text1.setBounds(670, 330, 350, 50);
        
        
        password1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        password1.setPreferredSize(new java.awt.Dimension(6, 22));
        pan.add(password1);
        password1.setBounds(670, 430, 350, 50);
        
        connect.setFont(new java.awt.Font("SERomand", 0, 36)); // NOI18N
        connect.setText("Entrer");
        connect.setOpaque(false);
        pan.add(connect);
        connect.setBounds(500, 660, 200, 50);
         connect.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                label4.setFont(new java.awt.Font("SERomand", 1, 48)); // NOI18N
                label4.setText("Tu es connecté!!");
                pan2.add(label4);
                label4.setBounds(270, 430, 360, 60);
                Fenetre.this.setContentPane(pan2);
                   
            }
        });

       this.setContentPane(pan);
       this.setVisible(true);
    }
}
   